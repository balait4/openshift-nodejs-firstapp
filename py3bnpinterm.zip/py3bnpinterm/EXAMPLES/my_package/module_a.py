#!/usr/bin/env python
# (c) 2017 John Strickler
#
def function_a():
    print("Hello from function_a")
