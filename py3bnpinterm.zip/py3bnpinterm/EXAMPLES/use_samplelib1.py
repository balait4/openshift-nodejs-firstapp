#!/usr/bin/env python
import samplelib  # <1>

samplelib.spam()  # <2>
samplelib.ham()
