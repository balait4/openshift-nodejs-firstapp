#!/usr/bin/env python
from samplelib import spam as pig, ham as hog  # <1>

pig()
hog()
