#!/usr/bin/env python

from electrical import *  # <1>
from navigation import *  # <2>

print(current())  # <3>
print(voltage())
print(amps())
