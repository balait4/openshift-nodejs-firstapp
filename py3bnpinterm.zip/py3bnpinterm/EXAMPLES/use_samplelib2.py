#!/usr/bin/env python
from samplelib import spam, ham  # <1>

spam()  # <2>
ham()
