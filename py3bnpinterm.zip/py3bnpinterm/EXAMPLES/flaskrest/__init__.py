#!/usr/bin/env python
# (c) 2016 John Strickler
#
